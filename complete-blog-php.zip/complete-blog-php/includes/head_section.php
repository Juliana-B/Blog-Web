<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@500&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="static/css/style.css">
	<meta charset="UTF-8">